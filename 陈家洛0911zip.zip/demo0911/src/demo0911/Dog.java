package demo0911;

import java.io.Serializable;

public class Dog extends Pet implements Serializable{

	
	public Dog(String petName, String speakType, String ownerName) {
		super(petName, speakType, ownerName);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void speakInfo() {
		// TODO Auto-generated method stub
		System.out.println(super.getSpeakType());
		
	}
	
	@Override
	public void playWithOwner(Pet p) {
		// TODO Auto-generated method stub
		super.playWithOwner(p);
	}

}

package demo0911;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class LearnSerialization implements Serializable{

	public byte version = 100;
	public byte count = 0;
	
	public static void main(String[] args) throws IOException {
		FileOutputStream fos = new FileOutputStream("D:\\Prj\\demo0911\\folder\\1.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		LearnSerialization ls = new LearnSerialization();
		oos.writeObject(ls);
		oos.flush();
		oos.close();
		
	}
	
	
}

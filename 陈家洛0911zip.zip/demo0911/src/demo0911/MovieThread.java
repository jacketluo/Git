package demo0911;

public class MovieThread implements Runnable{

	int num = 20;
	private Object obj = new Object();
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			synchronized (obj) {
				if(num>0) {
					try {
						Thread.sleep(500);
						--num;
						System.out.println(Thread.currentThread().getName()+"������Ʊ����Ʊ"+num);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}else {
					break;
				}
			}
			
		}
		
	}
	

}

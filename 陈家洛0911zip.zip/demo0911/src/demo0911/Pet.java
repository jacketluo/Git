package demo0911;

import java.io.Serializable;

public class Pet implements Serializable{
	
	private String petName;
	private String ownerName;
	private String speakType;
	
	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public String getSpeakType() {
		return speakType;
	}

	public void setSpeakType(String speakType) {
		this.speakType = speakType;
	}

	public Pet(String petName,String speakType,String ownerName) {
		this.petName = petName;
		this.speakType = speakType;
		this.ownerName = ownerName;
		// TODO Auto-generated constructor stub
	}
	
	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public void speakInfo() {
		System.out.println("˵����ʽ");
	}
	
	public void playWithOwner(Pet p) {
		System.out.println(petName+"���ں�����"+ownerName+"��ˣ");
	}

}

package demo0911;

public class TestMovieThread {
	public static void main(String[] args) {
		MovieThread tr = new MovieThread();
		Thread t1 = new Thread(tr,"����һ");
		Thread t2 = new Thread(tr,"���ڶ�");
		Thread t3 = new Thread(tr,"������");
		t1.start();
		t2.start();
		t3.start();
	}

}

package demo0911;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TestSerialization {

	public static void main(String[] args) throws IOException, ClassNotFoundException{
		FileInputStream fis = new FileInputStream("D:\\Prj\\demo0911\\folder\\1.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		LearnSerialization ls1 = (LearnSerialization) ois.readObject();
		System.out.println("version="+ls1.version);
		
	}
}

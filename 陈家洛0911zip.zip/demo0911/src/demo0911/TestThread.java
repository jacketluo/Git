package demo0911;

public class TestThread {
	public static void main(String[] args) {
		LearnThread t1 = new LearnThread("�߳�1");
		LearnThread t2 = new LearnThread("�߳�2");
		LearnThread t3 = new LearnThread("�߳�3");
		t3.setPriority(8);
		t1.start();
		t2.start();
		t3.start();
		
		Thread_runnable tr = new Thread_runnable();
		Thread t4 = new Thread(tr,"�߳�4");
		Thread t5 = new Thread(tr,"�߳�5");
		Thread t6 = new Thread(tr,"�߳�6");
		t4.start();
		t5.start();
		t6.start();
		
	}

}

package demo0911;

public class TestTicketThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ticket t = new Ticket(30, "��С��ս��", 35);
		TicketThread tt = new TicketThread(t);
		Thread t1 = new Thread(tt,"����һ");
		Thread t2 = new Thread(tt,"���ڶ�");
		Thread t3 = new Thread(tt,"������");
		t1.start();
		t2.start();
		t3.start();
		

	}

}

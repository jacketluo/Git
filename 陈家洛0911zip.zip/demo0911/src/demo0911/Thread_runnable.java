package demo0911;

public class Thread_runnable implements Runnable {

	@Override
	public void run() {
		System.out.println("���ƣ�"+Thread.currentThread().getName());
		System.out.println("���ȼ���"+Thread.currentThread().getPriority());
		System.out.println("�Ƿ��"+Thread.currentThread().isAlive());
		System.out.println("״̬��"+Thread.currentThread().getState());
		System.out.println("\n");
		
	}

}

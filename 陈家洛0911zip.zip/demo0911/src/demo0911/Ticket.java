package demo0911;

public class Ticket {
	
	private int ticketNum;
	private String ticketName;
	private double price;
	
	public Ticket(int ticketNum,String ticketName,double price) {
		this.ticketName = ticketName;
		this.ticketNum = ticketNum;
		this.price = price;
		// TODO Auto-generated constructor stub
	}

	public int getTicketNum() {
		return ticketNum;
	}

	public void setTicketNum(int ticketNum) {
		this.ticketNum = ticketNum;
	}

	public String getTicketName() {
		return ticketName;
	}

	public void setTicketName(String ticketName) {
		this.ticketName = ticketName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	
	
}

package demo0911;

public class TicketThread implements Runnable{
	Ticket t;
	int num;
	private Object obj = new Object();
	
	public TicketThread(Ticket t) {
		this.t = t;
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public void run() {
		while(true) {
			synchronized (t) {
				if(t.getTicketNum()>0) {
					try {
						Thread.sleep(500);
						System.out.println(Thread.currentThread().getName()+"������Ʊ"+t.getTicketName()+",��Ʊ"+sale(t));
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}else {
					break;
				}
			}
		}
		// TODO Auto-generated method stub
		
	}


	private int sale(Ticket t) {
		// TODO Auto-generated method stub
		num = t.getTicketNum();
		--num;
		t.setTicketNum(num);
		return num;
	}
	

}
